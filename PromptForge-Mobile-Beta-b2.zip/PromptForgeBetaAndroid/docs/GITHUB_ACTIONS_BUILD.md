# Cloud APK build with GitHub Actions

The project includes `.github/workflows/build-debug-apk.yml`.

When the project is pushed to a GitHub repository, the workflow builds `PromptForge-Beta-1.0.0-b2.apk` on Ubuntu using Java 17, Android SDK 36, Android Gradle Plugin 8.13.2 and Gradle 8.13. The finished APK is uploaded as a GitHub Actions artifact.

The workflow runs on pushes to `main` and can also be started manually with **Run workflow**.
