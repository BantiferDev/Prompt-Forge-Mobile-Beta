# Prompt Forge Beta APK test checklist

Build: 1.0.0-beta.2

- App launches directly into Prompt Forge with no browser chrome.
- Character profiles survive a force-close and relaunch.
- Body/style/outfit/pose/environment/lighting thumbnails load.
- Adult Options state and adult-only presets behave the same as desktop Beta.
- Athletic Subtle/Balanced/Strong behavior matches the desktop Beta snapshot.
- Forge Prompt and Prompt Inspector work.
- Copy Current Tab and Copy Full Pack work.
- Backup / Transfer > Export opens the Android save-file picker and writes JSON.
- Backup / Transfer > Import opens the Android picker, validates backup, and reloads.
- Reference image inputs open the Android image picker and display selected images.
- Portrait mode is usable on the cover screen.
- Inner Fold display uses the larger responsive layout.
- Rotate while a prompt is open and verify state survives.
- Android Back closes dialogs/drawers before exiting the app.
- Remote HTTPS model calls behave the same as PWA/desktop when configured.
