plugins {
    id("com.android.application")
}

android {
    namespace = "com.promptforge.beta"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.promptforge.beta"
        minSdk = 26
        targetSdk = 36
        versionCode = 10003
        versionName = "1.0.0-beta.3"
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.14.0")
}
