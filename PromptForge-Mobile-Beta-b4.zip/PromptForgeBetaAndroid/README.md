# Prompt Forge Beta Android

Native Android WebView wrapper for the Prompt Forge Beta 1.0 mobile build.

## Current mobile build
- Package: `com.promptforge.beta.debug` for debug APKs
- Version: `1.0.0-beta.4-debug`
- minSdk: 26
- target/compile SDK: 36
- Web content is bundled in `app/src/main/assets/promptforge/`
- Stable app origin: `https://appassets.androidplatform.net/assets/promptforge/index.html`

## Native integration
- Persistent WebView localStorage for Prompt Forge profiles/settings/history.
- Android file picker for JSON backup import and reference images.
- Android document saver for backup/quick-export JSON.
- Native clipboard bridge.
- Dark status/navigation bars.
- Fold/rotation support.
- Network permission for remote HTTPS APIs and future Tailscale/ComfyUI integration.
- WebView debugging enabled in this field-test build.
- System-bar inset handling for Android edge-to-edge devices.

## Build
Open the project root in a current Android Studio and choose **Build > Build APK(s)**.
The project uses Android Gradle Plugin 8.13.2 and Gradle 8.13.

For Windows, the easiest local build path is to double-click `BUILD_BETA_APK_WINDOWS.bat`. It locates the Android SDK, downloads Gradle 8.13 if needed, builds the debug APK, and copies it to `PromptForge-Beta-1.0.0-b4.apk`.

Expected Gradle output:
`app/build/outputs/apk/debug/app-debug.apk`

See `docs/APK_TEST_CHECKLIST.md` for field testing.

## Cloud build while away from the desktop
A GitHub Actions workflow is included at `.github/workflows/build-debug-apk.yml`. If this project is pushed to GitHub, Actions can compile the debug APK and expose it as a downloadable build artifact without requiring the desktop machine to be online.
