(function(PF){
  'use strict';
  const LIGHT_VARIATIONS={
   'warm-practical':['amber key light from nearby lamps','soft warm falloff across the scene','gentle cool ambient fill behind the warm practicals'],
   'moonlit-blue':['cool silver-blue rim light','soft moonlit highlights along the silhouette','deep blue ambient fill with gentle shadow detail'],
   'blue-hour':['soft cobalt ambient fill','subtle cool-to-warm transition near practical lights','muted dusk contrast with gentle edge light'],
   'purple-neon':['magenta-violet edge light','soft cyan fill balancing the purple neon','colored neon reflections across nearby surfaces'],
   'golden-rim':['stronger honey-gold edge light','soft warm fill preserving facial detail','sunlit highlights along hair and shoulders'],
   'club-neon':['richer magenta and blue separation','warm amber bar light balancing the neon','colored bokeh reflecting across polished surfaces'],
   'bathroom-warm':['soft mirror light wrapping evenly around the face','warm vanity fill with clean highlights','subtle cool reflection from glass and marble surfaces'],
   'bedroom-warm':['soft bedside lamp key light','gentle cool city-light fill from the window','warm shadow transitions across the bedding'],
   'golden-hour':['honey-toned sunlight across the scene','soft sunset rim light','warm reflected fill preserving natural shadow detail']
  };
  const LIGHTS=[
   ['warm-practical','Warm Practical','assets/lighting/warm-practical.webp','warm practical lamp lighting, flattering soft shadows'],['moonlit-blue','Moonlit Blue','assets/lighting/moonlit-blue.webp','cool moonlight, soft blue rim light'],['blue-hour','Blue Hour','assets/lighting/blue-hour.webp','blue-hour ambient light, soft cinematic contrast'],['purple-neon','Purple Neon','assets/lighting/purple-neon.webp','purple-magenta neon glow, cinematic rim lighting'],['golden-rim','Golden Rim','assets/lighting/golden-rim.webp','warm golden rim light, soft fill on face'],['club-neon','Club Neon','assets/sets/bar-club-scene.webp','mixed magenta, blue and warm amber nightlife lighting with rich bokeh'],['bathroom-warm','Bathroom Warm','assets/sets/bathroom-mirror.webp','soft warm vanity illumination with clean flattering fill'],['bedroom-warm','Bedroom Warm','assets/sets/bedtime.webp','warm bedside lamp glow with soft cool city fill'],['golden-hour','Golden Hour','assets/sets/summer-vibes.webp','rich golden-hour sunlight, warm skin tones, soft natural rim light']
  ].map(([id,name,img,prompt])=>({id,name,img,prompt}));
  PF.registerCatalog('lighting',1,{LIGHT_VARIATIONS:LIGHT_VARIATIONS,LIGHTS:LIGHTS});
})(window.PromptForge);
