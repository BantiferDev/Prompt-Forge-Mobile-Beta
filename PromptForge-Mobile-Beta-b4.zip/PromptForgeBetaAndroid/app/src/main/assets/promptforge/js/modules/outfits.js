(function(PF){
  'use strict';
  PF.registerModule('outfits',{status:'catalog-migrated',owns:"Outfit catalog, adult outfit controls, required/allowed/blocked data",next:"Migration 4: normalize outfit schema and move behavior out of compatibility runtime"});
})(window.PromptForge);
