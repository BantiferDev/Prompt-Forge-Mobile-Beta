(function(PF){
  'use strict';
  PF.registerModule('characters',{status:'scaffold',owns:"Character profiles, complexion, age validation, Adult Options",next:"migrate v7 localStorage to versioned profile schema"});
})(window.PromptForge);
