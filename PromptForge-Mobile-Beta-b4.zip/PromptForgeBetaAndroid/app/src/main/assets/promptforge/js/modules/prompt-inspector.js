(function(PF){
  'use strict';

  const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[ch]));
  const service=PF.services.promptInspector=PF.services.promptInspector||{};

  service.getCurrent=function(){return window._pf7pack?.inspector||null};
  service.exportCurrent=function(){
    const data=service.getCurrent();
    return data?JSON.stringify(data,null,2):'';
  };
  service.render=function(){
    const host=document.getElementById('promptInspectorList');
    const meta=document.getElementById('promptInspectorMeta');
    const target=document.getElementById('promptInspectorTarget');
    const search=document.getElementById('promptInspectorSearch');
    if(!host||!meta)return;
    const data=service.getCurrent();
    if(!data){
      meta.textContent='Forge a prompt first to capture provenance.';
      host.innerHTML='<div class="inspector-empty">No prompt provenance is available yet.</div>';
      return;
    }
    const targetValue=target?.value||'all';
    const query=(search?.value||'').trim().toLowerCase();
    const context=Object.entries(data.context||{}).filter(([,v])=>v!=null&&v!=='').map(([k,v])=>`${k}: ${v}`).join(' • ');
    meta.textContent=`${data.fragments?.length||0} traced fragments • ${data.dialect||'Unknown dialect'}${context?' • '+context:''}`;
    const rows=(data.fragments||[]).filter(f=>(targetValue==='all'||f.target===targetValue)&&(!query||[f.target,f.module,f.preset,f.rule,f.text].join(' ').toLowerCase().includes(query)));
    if(!rows.length){host.innerHTML='<div class="inspector-empty">No fragments match the current filter.</div>';return}
    host.innerHTML=rows.map(f=>`<article class="inspector-row">
      <div class="inspector-row-head"><span class="inspector-target">${esc(f.target)}</span><strong>${esc(f.module)}</strong><span class="inspector-preset">${esc(f.preset)}</span></div>
      <div class="inspector-rule">${esc(f.rule)}${f.meta?.locked?' • locked':''}${f.meta?.variationExcluded?' • excluded from variation':''}</div>
      <div class="inspector-text">${esc(f.text)}</div>
    </article>`).join('');
  };

  function openInspector(){
    service.render();
    const dialog=document.getElementById('promptInspectorDialog');
    if(dialog&&!dialog.open)dialog.showModal();
  }

  function bind(){
    document.getElementById('inspectPromptBtn')?.addEventListener('click',openInspector);
    document.getElementById('promptInspectorTarget')?.addEventListener('change',service.render);
    document.getElementById('promptInspectorSearch')?.addEventListener('input',service.render);
    document.getElementById('copyInspectorBtn')?.addEventListener('click',async()=>{
      const payload=service.exportCurrent();if(!payload)return;
      try{await navigator.clipboard.writeText(payload)}catch{
        const ta=document.createElement('textarea');ta.value=payload;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();
      }
      const btn=document.getElementById('copyInspectorBtn');if(btn){const old=btn.textContent;btn.textContent='✓ Copied';setTimeout(()=>btn.textContent=old,1200)}
    });
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind,{once:true});else bind();
  PF.registerModule('prompt-inspector',{status:'active',owns:'Prompt provenance viewer and diagnostics export',next:'consume typed prompt blocks directly during Migration 6'});
})(window.PromptForge);
