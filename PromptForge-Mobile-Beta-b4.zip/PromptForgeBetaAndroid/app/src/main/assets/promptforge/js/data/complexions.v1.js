(function(PF){
  'use strict';
  const COMPLEXIONS={
   auto:{name:'Auto',tone:'#b98368',prompt:''},
   pale:{name:'Pale',tone:'#f2d6c8',prompt:'pale porcelain skin tone'},
   fair:{name:'Fair',tone:'#e8bda5',prompt:'fair skin tone'},
   light:{name:'Light',tone:'#d89d7b',prompt:'light skin tone'},
   medium:{name:'Medium',tone:'#bd7d59',prompt:'medium skin tone'},
   tan:{name:'Tan',tone:'#a96848',prompt:'warm tan skin tone'},
   deep:{name:'Deep',tone:'#75462f',prompt:'deep brown skin tone'},
   dark:{name:'Dark',tone:'#45291f',prompt:'dark rich brown skin tone'}
  };
  PF.registerCatalog('complexions',1,{COMPLEXIONS:COMPLEXIONS});
})(window.PromptForge);
