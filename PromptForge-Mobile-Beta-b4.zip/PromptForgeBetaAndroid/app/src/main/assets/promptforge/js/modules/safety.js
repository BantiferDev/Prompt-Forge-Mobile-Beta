(function(PF){
  'use strict';
  PF.registerModule('safety',{status:'scaffold',owns:"18+ profile validation and youth-coded conflict blocking",next:"centralize all validation into one fail-closed service"});
})(window.PromptForge);
