(function(PF){
  'use strict';
  const RENDER_MODELS={
   krea2:{name:'Krea 2 + Weighted Node',mode:'weighted',note:'Uses ComfyUI weighted-prompt syntax for Krea 2 when a weighted prompt node is in the workflow. Body-shape presets receive numeric emphasis for a stronger starting silhouette.'},
   flux:{name:'FLUX',mode:'natural',note:'Natural-language prompting; use explicit visual descriptions rather than parenthetical numeric weights.'},
   sdxl:{name:'SDXL / ComfyUI CLIP',mode:'weighted',note:'Uses ComfyUI-style (term:weight) syntax for body emphasis and concise comma-separated prompting.'},
   pony:{name:'Pony / Illustrious',mode:'weighted',note:'Uses weighted tag-style prompting with stronger body-shape terms.'},
   qwen:{name:'Qwen Image',mode:'natural',note:'Natural descriptive prompting; numeric weights are omitted for compatibility.'},
   generic:{name:'Generic CLIP',mode:'weighted',note:'Uses standard parenthetical numeric prompt weights.'}
  };
  const CAMERA_VARIATIONS={
   '50mm natural':['balanced three-quarter framing','natural eye-level composition','medium portrait framing with comfortable environmental context'],
   '35mm environmental':['environment-forward composition','slightly wider three-quarter framing','fuller scene context while keeping the character prominent'],
   '85mm portrait':['shallow-depth portrait framing','compressed background with stronger subject isolation','closer portrait crop while preserving the selected pose'],
   '24mm wide':['wide environmental composition','strong foreground-to-background depth','slightly expanded scene framing without distorting anatomy'],
   'low angle':['subtle upward perspective','heroic low-angle composition','camera positioned just below torso level while preserving natural proportions']
  };
  const MOOD_VARIATIONS={
   confident:['relaxed direct gaze','subtle knowing smile','poised self-assured expression'],
   regal:['composed authoritative gaze','restrained royal expression','calm elevated posture and expression'],
   intimate:['soft calm gaze','quiet relaxed expression','gentle close-camera expression'],
   ominous:['steady serious gaze','restrained unreadable expression','subtle tension in the eyes'],
   warm:['gentle natural smile','soft welcoming expression','relaxed friendly gaze'],
   playful:['subtle amused grin','bright mischievous eyes','light teasing expression']
  };
  PF.registerCatalog('rendering',1,{RENDER_MODELS:RENDER_MODELS,CAMERA_VARIATIONS:CAMERA_VARIATIONS,MOOD_VARIATIONS:MOOD_VARIATIONS});
})(window.PromptForge);
