(function(PF){
  'use strict';
  PF.registerModule('settings',{status:'scaffold',owns:"Generation defaults, themes, workflow settings, schema migrations",next:"version storage keys and migrate v7 settings"});
})(window.PromptForge);
