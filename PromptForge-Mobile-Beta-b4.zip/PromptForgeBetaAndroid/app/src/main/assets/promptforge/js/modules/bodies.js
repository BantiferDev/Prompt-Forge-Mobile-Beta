(function(PF){
  'use strict';
  PF.registerModule('bodies',{status:'catalog-migrated',owns:"Body presets, weight tiers, body-specific modifiers, Athletic context rules",next:"Migration 3: move body compiler + Athletic context rules out of compatibility runtime"});
})(window.PromptForge);
