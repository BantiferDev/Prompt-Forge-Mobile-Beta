(function(PF){
  'use strict';
  PF.registerModule('styles',{status:'catalog-migrated',owns:"Render styles and style-specific prompt language",next:"Migration 3: move style modifiers/compiler out of compatibility runtime"});
})(window.PromptForge);
