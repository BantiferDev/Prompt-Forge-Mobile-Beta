(function(PF){
  'use strict';
  const ENV_VARIATIONS={
   'celestial-temple':['faint constellations visible beyond the columns','subtle floating dust motes catching the light','distant ceremonial banners between the marble columns','small reflecting pools along the temple floor'],
   'luxury-suite':['subtle marble accents near the windows','plush seating arranged beside the city view','soft curtains framing the large windows','minimal floral arrangement on a polished side table'],
   'neon-city':['rain-slick reflections across the pavement','soft steam drifting from a street vent','blurred sign reflections in nearby glass','distant traffic bokeh through the rain'],
   'moonlit-beach':['dark palm silhouettes beyond the shoreline','a bright moon trail across the water','small rock formations near the surf','gentle sea mist close to the waterline'],
   'balcony-interior':['potted greenery near the railing','soft sheer curtains moving near the doorway','small lanterns along the balcony edge','a compact lounge chair beside the view'],
   'cozy-bedroom':['layered throw blankets at the foot of the bed','a small stack of books on the nightstand','soft curtains framing the city view','subtle decorative pillows in muted tones'],
   'nightclub-bar':['backlit bottles behind the bar','subtle brass fixtures along the counter','blurred crowd silhouettes in the distance','glossy reflections across the polished bar top'],
   'modern-bathroom':['rolled towels beside the vanity','a small orchid near the mirror','subtle steam on the glass shower','minimal spa accessories arranged on the counter'],
   'summer-resort':['light cabana drapes near the pool','small marina boats in the distance','palm fronds framing the terrace','sunlit reflections across the pool surface'],
   'yoga-studio':['neatly stacked yoga blocks near the wall','large mirrors reflecting the studio space','rolled towels and a water bottle near the mat area','lush indoor plants beside the tall windows']
  };
  const ENVS=[
   ['celestial-temple','Celestial Temple','assets/environments/celestial-temple.webp','grand celestial temple, marble columns, cosmic sky'],['luxury-suite','Luxury Suite','assets/environments/luxury-suite.webp','upscale hotel suite, warm interior, large windows'],['neon-city','Neon City','assets/environments/neon-city.webp','rainy neon-lit city street, reflective pavement'],['moonlit-beach','Moonlit Beach','assets/environments/moonlit-beach.webp','moonlit shoreline, dark ocean, soft waves'],['balcony-interior','Balcony Interior','assets/environments/balcony-interior.webp','elegant balcony or warm interior overlooking the night'],['cozy-bedroom','Cozy Bedroom','assets/environments/cozy-bedroom.webp','warm upscale bedroom or lounge interior with soft bedding and city lights'],['nightclub-bar','Nightclub Bar','assets/environments/nightclub-bar.webp','upscale modern nightclub bar with polished surfaces and blurred crowd'],['modern-bathroom','Modern Bathroom','assets/environments/modern-bathroom.webp','luxury modern bathroom with illuminated mirror, glass shower and marble vanity'],['summer-resort','Summer Resort','assets/environments/summer-resort.webp','golden-hour resort terrace overlooking marina water and palms'],['yoga-studio','Yoga Studio','assets/environments/yoga-studio.webp','bright warm home yoga studio with plants, wood floor and tall windows']
  ].map(([id,name,img,prompt])=>({id,name,img,prompt}));
  PF.registerCatalog('environments',1,{ENV_VARIATIONS:ENV_VARIATIONS,ENVS:ENVS});
})(window.PromptForge);
