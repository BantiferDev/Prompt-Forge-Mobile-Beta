(function(PF){
  'use strict';
  PF.registerModule('prompt-assembly',{status:'provenance-enabled',owns:"Identity → Body → Style → Outfit → Pose → Environment → Lighting → Camera/Mood → Variation → dialect",next:"Migration 6: replace legacy string assembly with typed prompt blocks; provenance contract already active"});
})(window.PromptForge);
