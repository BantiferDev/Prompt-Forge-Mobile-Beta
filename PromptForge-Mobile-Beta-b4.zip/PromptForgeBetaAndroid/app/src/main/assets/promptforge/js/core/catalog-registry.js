(function(PF){
  'use strict';
  PF.data.catalogs=PF.data.catalogs||{};
  PF.registerCatalog=function(domain,schemaVersion,payload){
    if(!domain||typeof domain!=='string')throw new Error('Prompt Forge catalog requires a domain name.');
    if(!Number.isInteger(schemaVersion)||schemaVersion<1)throw new Error(`Invalid schema version for catalog: ${domain}`);
    if(!payload||typeof payload!=='object'||Array.isArray(payload))throw new Error(`Invalid catalog payload: ${domain}`);
    if(PF.data.catalogs[domain])throw new Error(`Duplicate catalog registration: ${domain}`);
    const catalog=Object.freeze({schemaVersion,domain,...payload});
    PF.data.catalogs[domain]=catalog;
    PF.diagnostics?.log?.('catalog-registered',{domain,schemaVersion,keys:Object.keys(payload)});
    return catalog;
  };
  PF.catalogStatus=function(){return Object.values(PF.data.catalogs).map(({domain,schemaVersion,...rest})=>({domain,schemaVersion,keys:Object.keys(rest)}));};
})(window.PromptForge);
