(function(PF){
  'use strict';
  const POSE_VARIATIONS={
   'standing-confident':['slight hip shift while keeping the confident stance','one hand resting naturally at the hip','chin lifted slightly','shoulders angled subtly toward camera'],
   'seated-edge':['one knee set slightly forward','hands resting naturally beside the hips','torso angled gently toward camera','chin tilted slightly while remaining seated at the edge'],
   'reclined-lounge':['one arm braced comfortably behind the torso','one knee raised slightly higher','shoulders settled deeper into the cushions','torso turned subtly toward camera while remaining reclined'],
   'over-shoulder':['chin turned a little farther toward camera','one hand resting lightly at the waist','near shoulder lowered slightly','weight shifted subtly through the back hip while maintaining the over-shoulder pose'],
   'throne-sit':['one elbow resting loosely on an armrest','chin raised slightly','one ankle angled outward','torso settled asymmetrically into the throne while keeping the dominant seated pose'],
   'bar-lean':['fingers relaxed against the bar surface','hip angled slightly away from the counter','shoulders turned subtly toward camera','chin tipped slightly while maintaining the bar lean'],
   'mirror-selfie':['phone held just below eye level','free hand resting lightly at the hip','torso angled slightly toward the mirror','one knee relaxed while maintaining the mirror-selfie stance'],
   'kneeling-stretch':['hands lightly clasped overhead','torso lengthened upward through the stretch','hips settled evenly over the heels','chin raised slightly while maintaining the kneeling stretch'],
   'kneeling-tease':['one hand resting higher on the thigh while keeping the kneeling pose','chin tipped slightly toward camera','hips settled a little farther back while remaining upright on the knees','shoulders angled subtly while preserving the adult kneeling pose'],
   'bed-edge-tease':['hands braced slightly farther behind the hips','one knee angled subtly outward while remaining seated at the edge','torso leaned back a little farther without changing the seated pose','chin lowered slightly with direct eye contact'],
   'reclined-open':['one arm relaxed farther behind the torso','raised knee angled slightly outward','shoulders settled a little lower while remaining supported on the elbows','head turned subtly toward camera while preserving the reclined pose'],
   'all-fours-glance':['weight shifted subtly toward one hand while keeping the hands-and-knees pose','chin turned a little farther over the shoulder','back arched slightly more while maintaining natural anatomy','one knee positioned a little farther forward without changing the pose family'],
   'bent-forward-glance':['hands placed slightly higher on the thighs','torso angled a little farther forward while maintaining balance','head turned farther back toward camera','hips shifted subtly to one side while keeping the bent-forward pose'],
   'straddle-sit':['hands resting higher on the thighs while keeping the straddle sit','torso leaned slightly toward the chair back','chin raised subtly','one shoulder rotated gently toward camera while remaining seated astride'],
   'laid-back-legs-up':['ankles crossed lightly while keeping both legs elevated','one hand resting near the hip while the other supports the reclined posture','chin tipped slightly toward camera with a relaxed expression','legs bent a little more loosely while maintaining the elevated laid-back pose']
  };
  const POSES=[
   ['standing-confident','Standing Confident','assets/poses/standing-confident.webp','standing contrapposto, confident posture, weight on one leg',false],
   ['seated-edge','Seated Edge','assets/poses/seated-edge.webp','seated on the edge, knees angled, torso slightly forward',false],
   ['reclined-lounge','Reclined Lounge','assets/poses/reclined-lounge.webp','reclined lounge pose, one knee bent, relaxed shoulders',false],
   ['over-shoulder','Over Shoulder','assets/poses/over-shoulder.webp','body turned partly away, looking back over one shoulder',false],
   ['throne-sit','Throne Sit','assets/poses/throne-sit.webp','asymmetrical throne pose, one leg elevated over the armrest, relaxed dominant posture',false],
   ['bar-lean','Bar Lean','assets/sets/bar-club-scene.webp','standing at a bar, one forearm resting on the counter, relaxed confident posture',false],
   ['mirror-selfie','Mirror Selfie','assets/sets/bathroom-mirror.webp','standing at a bathroom mirror holding a phone in one hand, other hand braced lightly on vanity',false],
   ['kneeling-stretch','Kneeling Stretch','assets/sets/yoga-wellness.webp','kneeling on a yoga mat with both arms raised overhead in a relaxed stretch',false],
   ['kneeling-tease','Kneeling Tease','assets/poses/adult-kneeling-tease.webp','adult sensual kneeling pose, upright on both knees with thighs comfortably apart, hands resting naturally on the thighs, confident direct gaze',true],
   ['bed-edge-tease','Bed Edge Tease','assets/poses/adult-bed-edge-tease.webp','adult sensual seated pose on the edge of a bed or bench, knees comfortably apart, torso leaning slightly back with hands braced beside the hips',true],
   ['reclined-open','Reclined Tease','assets/poses/adult-reclined-tease.webp','adult sensual reclined pose, upper body supported comfortably on the elbows, one knee raised and legs relaxed apart, confident gaze toward camera',true],
   ['all-fours-glance','All Fours Glance','assets/poses/adult-all-fours.webp','adult sensual pose on hands and knees, back naturally arched, head turned to look back over one shoulder',true],
   ['bent-forward-glance','Bent Forward Glance','assets/poses/adult-bent-forward.webp','adult sensual standing pose with the torso leaned forward slightly and hips set back, hands resting on the thighs or a nearby surface, looking back toward camera',true],
   ['straddle-sit','Straddle Sit','assets/poses/adult-straddle-sit.webp','adult sensual seated straddle pose on a chair or bench, torso upright, hands resting naturally on the thighs or chair back',true],
   ['laid-back-legs-up','Laid Back Legs Up','assets/poses/adult-reclined-tease.webp','adult sensual laid-back pose on a bed or lounge, upper body reclined comfortably, hips relaxed, both legs raised and bent upward in a playful elevated-leg pose, confident gaze toward camera',true]
  ].map(([id,name,img,prompt,adultOnly=false])=>({id,name,img,prompt,adultOnly}));
  PF.registerCatalog('poses',1,{POSE_VARIATIONS:POSE_VARIATIONS,POSES:POSES});
})(window.PromptForge);
