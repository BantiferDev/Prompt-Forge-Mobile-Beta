(function(PF){
  'use strict';
  PF.registerModule('variation',{status:'scaffold',owns:"Controlled variation + recent anti-repeat memory",next:"extract deterministic variation service"});
})(window.PromptForge);
