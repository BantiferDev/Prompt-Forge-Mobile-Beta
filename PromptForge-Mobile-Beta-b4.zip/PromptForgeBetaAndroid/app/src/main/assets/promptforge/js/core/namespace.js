(function(){
  'use strict';
  const root=window.PromptForge=window.PromptForge||{};
  root.meta={name:'Prompt Forge',version:'1.0.0-beta-migration1',schemaVersion:1,catalogSchemaVersion:1,architecture:'modular-strangler'};
  root.modules=root.modules||{};
  root.data=root.data||{};
  root.services=root.services||{};
  root.diagnostics=root.diagnostics||{events:[]};
  root.diagnostics.log=function(type,detail={}){this.events.push({time:new Date().toISOString(),type,detail});if(this.events.length>200)this.events.shift();};
})();
