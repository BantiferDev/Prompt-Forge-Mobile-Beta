(function(PF){
  'use strict';
  PF.registerModule=function(name,descriptor){
    PF.modules[name]=Object.freeze({name,status:'scaffold',...descriptor});
  };
  PF.moduleStatus=function(){return Object.values(PF.modules).map(({name,status,owns,next})=>({name,status,owns,next}));};
})(window.PromptForge);
