(function(PF){
  'use strict';
  const $=id=>document.getElementById(id);
  const isMobile=()=>window.matchMedia('(max-width:1000px)').matches;
  const nav=$('mobileNavDrawer'), selection=$('mobileSelectionDrawer'), backdrop=$('mobileBackdrop');
  const mobileForge=$('mobileForgeBtn'), mobilePrompt=$('mobilePromptBtn');
  const nativeAndroid=!!window.PromptForgeAndroid;
  const forge=$('forgeBtn'), viewPrompt=$('viewPromptBtn');

  function closeDrawers(){
    nav?.classList.remove('mobile-open');
    selection?.classList.remove('mobile-open');
    if(backdrop)backdrop.hidden=true;
    document.body.classList.remove('mobile-drawer-active');
  }
  function openDrawer(which){
    if(!isMobile())return;
    closeDrawers();
    const target=which==='nav'?nav:selection;
    target?.classList.add('mobile-open');
    if(backdrop)backdrop.hidden=false;
    document.body.classList.add('mobile-drawer-active');
  }

  $('mobileMenuBtn')?.addEventListener('click',()=>openDrawer('nav'));
  $('mobileSelectionBtn')?.addEventListener('click',()=>openDrawer('selection'));
  $('mobileNavClose')?.addEventListener('click',closeDrawers);
  $('mobileSelectionClose')?.addEventListener('click',closeDrawers);
  backdrop?.addEventListener('click',closeDrawers);
  window.addEventListener('resize',()=>{if(!isMobile())closeDrawers()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawers()});

  nav?.querySelectorAll('[data-scroll],[data-open]').forEach(btn=>btn.addEventListener('click',()=>setTimeout(closeDrawers,0)));
  mobileForge?.addEventListener('click',()=>{closeDrawers();forge?.click()});
  mobilePrompt?.addEventListener('click',()=>{closeDrawers();if(viewPrompt&&!viewPrompt.disabled)viewPrompt.click()});

  // Surface Forge failures on mobile even when Generation Settings is closed.
  const forgeError=$('error');
  let noticeTimer=null;
  function showMobileNotice(message){
    if(!isMobile()||!message)return;
    let notice=$('mobileNotice');
    if(!notice){notice=document.createElement('div');notice.id='mobileNotice';notice.className='mobile-notice';notice.setAttribute('role','status');document.body.appendChild(notice)}
    notice.textContent=message;notice.classList.add('show');
    clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>notice.classList.remove('show'),4200);
  }
  if(forgeError)new MutationObserver(()=>{const message=forgeError.textContent.trim();if(message)showMobileNotice(message)}).observe(forgeError,{childList:true,characterData:true,subtree:true});

  function syncMobileActions(){
    if(mobileForge&&forge){mobileForge.disabled=forge.disabled;mobileForge.setAttribute('aria-busy',forge.disabled?'true':'false')}
    if(mobilePrompt&&viewPrompt)mobilePrompt.disabled=viewPrompt.disabled;
  }
  syncMobileActions();
  if(forge)new MutationObserver(syncMobileActions).observe(forge,{attributes:true,attributeFilter:['disabled']});
  if(viewPrompt)new MutationObserver(syncMobileActions).observe(viewPrompt,{attributes:true,attributeFilter:['disabled']});
  window.setInterval(syncMobileActions,1000);

  // PWA install lifecycle. The install button appears only when the browser exposes an install prompt.
  let deferredInstall=null;
  const installButtons=[$('installAppBtn'),$('sidebarInstallApp')].filter(Boolean);
  function standalone(){return window.matchMedia('(display-mode: standalone)').matches||window.navigator.standalone===true}
  function refreshInstallButtons(){installButtons.forEach(b=>b.hidden=standalone()||!deferredInstall)}
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;refreshInstallButtons()});
  window.addEventListener('appinstalled',()=>{deferredInstall=null;refreshInstallButtons();closeDrawers()});
  async function requestInstall(){
    if(!deferredInstall)return;
    deferredInstall.prompt();
    try{await deferredInstall.userChoice}catch{}
    deferredInstall=null;refreshInstallButtons();
  }
  installButtons.forEach(b=>b.addEventListener('click',requestInstall));
  refreshInstallButtons();
  if(nativeAndroid){installButtons.forEach(b=>b.hidden=true);document.documentElement.classList.add('native-android')}

  // Register the offline app shell when served from a secure context (HTTPS or localhost).
  if(!nativeAndroid&&'serviceWorker' in navigator){
    window.addEventListener('load',()=>{
      if(window.isSecureContext||location.hostname==='localhost'||location.hostname==='127.0.0.1'){
        navigator.serviceWorker.register('./sw.js',{scope:'./'}).catch(()=>{});
      }
    });
  }

  // Device-to-device backup/transfer. Only Prompt Forge-prefixed keys are included.
  const KEY_PREFIXES=['pf7-','pfbeta-','prompt-forge-'];
  function isPromptForgeKey(key){return KEY_PREFIXES.some(prefix=>key.startsWith(prefix))}
  function collectStorage(){
    const storage={};
    for(let i=0;i<localStorage.length;i++){
      const key=localStorage.key(i);
      if(key&&isPromptForgeKey(key))storage[key]=localStorage.getItem(key);
    }
    return storage;
  }
  function downloadJson(name,value){
    const content=JSON.stringify(value,null,2);
    if(nativeAndroid&&window.PromptForgeAndroid?.exportText){window.PromptForgeAndroid.exportText(name,'application/json',content);return}
    const blob=new Blob([content],{type:'application/json'});
    const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),0);
  }
  function transferStatus(message,kind='normal'){
    const el=$('dataTransferStatus');if(!el)return;el.textContent=message;el.dataset.kind=kind;
  }
  function openTransfer(){closeDrawers();$('dataTransferDialog')?.showModal()}
  $('openDataTransfer')?.addEventListener('click',openTransfer);
  $('exportAppData')?.addEventListener('click',()=>{
    const now=new Date();
    const stamp=now.toISOString().slice(0,10);
    const payload={app:'Prompt Forge',schemaVersion:1,exportedAt:now.toISOString(),storage:collectStorage()};
    downloadJson(`prompt-forge-backup-${stamp}.json`,payload);
    transferStatus(`Exported ${Object.keys(payload.storage).length} Prompt Forge data entries.`,'success');
  });
  $('importAppData')?.addEventListener('click',()=>$('importAppDataFile')?.click());
  $('importAppDataFile')?.addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{
      const data=JSON.parse(await file.text());
      if(!data||data.app!=='Prompt Forge'||data.schemaVersion!==1||!data.storage||typeof data.storage!=='object')throw new Error('This is not a valid Prompt Forge backup.');
      const entries=Object.entries(data.storage).filter(([key,value])=>isPromptForgeKey(key)&&typeof value==='string');
      if(!entries.length)throw new Error('The backup contains no Prompt Forge browser data.');
      if(!window.confirm(`Import ${entries.length} Prompt Forge data entries? This replaces Prompt Forge browser data on this device, then reloads the app.`)){e.target.value='';return}
      const toRemove=[];for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key&&isPromptForgeKey(key))toRemove.push(key)}
      toRemove.forEach(key=>localStorage.removeItem(key));entries.forEach(([key,value])=>localStorage.setItem(key,value));
      transferStatus(`Imported ${entries.length} entries. Reloading…`,'success');
      setTimeout(()=>location.reload(),450);
    }catch(err){transferStatus(err?.message||String(err),'error')}
    finally{e.target.value=''}
  });

  // Publish mobile/PWA capability as a Beta module diagnostic.
  if(PF?.registerModule){
    try{PF.registerModule('mobile-pwa',{status:'active',owns:'Responsive phone UI, PWA install/offline shell, device data transfer',schemaVersion:1})}catch{}
  }
})(window.PromptForge);
