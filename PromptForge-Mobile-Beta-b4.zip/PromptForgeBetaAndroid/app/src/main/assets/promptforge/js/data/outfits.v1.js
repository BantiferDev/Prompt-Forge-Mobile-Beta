(function(PF){
  'use strict';
  const OUTFITS=[
   ['lace-set','Lace Set','assets/outfits/lace-set.webp','matching lace lingerie set, delicate scalloped lace, tasteful adult boudoir styling',true],['sheer-set','Sheer Set','assets/outfits/sheer-set.webp','sheer lace lingerie set, translucent embroidered fabric, smooth supported fabric across the bust, strategically denser embroidery over the nipple area, elegant adult fashion styling',true],['silk-robe','Silk Robe','assets/outfits/silk-robe.webp','loose silk robe with elegant drape and soft folds',false],['casual-tank','Casual Tank','assets/outfits/casual-tank.webp','fitted casual tank top with simple everyday styling',false],['red-dress','Red Dress','assets/outfits/red-dress.webp','fitted red evening dress, polished glamour',false],['bikini','Bikini','assets/outfits/bikini.webp','simple elegant bikini, beach-ready styling',false],['goddess-gown','Goddess Gown','assets/outfits/goddess-gown.webp','ornate celestial goddess gown, metallic filigree, gemstone details',false],['warrior-armor','Warrior Armor','assets/outfits/warrior-armor.webp','fitted ceremonial warrior armor, metallic filigree and refined accent detailing',false],['academic-blazer','Academic Blazer','assets/outfits/academic-blazer.webp','adult collegiate-inspired blazer, blouse, and tailored skirt',false],['leather-look','Leather Look','assets/outfits/leather-look.webp','sleek leather-inspired fashion outfit',false],['cozy-sweater','Cozy Sweater','assets/outfits/cozy-sweater.webp','soft knit sweater, relaxed seasonal styling',false],['business-chic','Business Chic','assets/outfits/business-chic.webp','tailored business-chic outfit, fitted blazer and blouse',false],['lounge-set','Lounge Set','assets/sets/casual-lounge.webp','soft fitted lounge top and shorts with cozy knit cardigan',false],['night-out-dress','Night-Out Dress','assets/sets/bar-club-scene.webp','fitted cocktail mini dress, sleek upscale nightlife styling',false],['mirror-cami','Mirror Cami','assets/sets/bathroom-mirror.webp','ribbed camisole with delicate lace trim and matching soft lounge shorts',false],['sleep-set','Sleep Set','assets/sets/bedtime.webp','soft camisole and matching sleep shorts with delicate trim',false],['summer-dress','Summer Dress','assets/sets/summer-vibes.webp','light breezy sundress with feminine summer styling',false],['activewear','Activewear','assets/sets/yoga-wellness.webp','coordinated sports bra and matching fitted yoga bottoms with clean trim',false],['nude','Nude','assets/outfits/nude-placeholder.webp','adult nude figure, fully unclothed, no garments or underlayers, natural adult nudity',true]
  ].map(([id,name,img,prompt,adultOnly=false])=>({id,name,img,prompt,adultOnly}));
  const ADULT_OUTFIT_RULES={
   'lace-set':{label:'Lace Set',fields:[
    {id:'color',label:'Color',options:[['auto','Auto'],['black','Black'],['red','Red'],['emerald','Emerald Green'],['ivory','Ivory'],['burgundy','Burgundy'],['navy','Deep Navy']]},
    {id:'structure',label:'Structure',options:[['auto','Auto'],['two-piece','Two-piece'],['bodysuit','One-piece Bodysuit']]},
    {id:'top',label:'Top Style',when:s=>s.structure!=='bodysuit',options:[['auto','Auto'],['bralette','Bralette'],['balconette','Balconette'],['plunge','Plunge']]},
    {id:'bottom',label:'Bottom Style',when:s=>s.structure!=='bodysuit',options:[['auto','Auto'],['matching','Matching Classic'],['high-waist','High-waisted'],['high-cut','High-cut']]},
    {id:'extras',label:'Extras',options:[['auto','Auto'],['none','None'],['garter','Garter Belt'],['stockings','Matching Thigh-highs'],['garter-stockings','Garter + Stockings']]}
   ]},
   'sheer-set':{label:'Sheer Set',fields:[
    {id:'color',label:'Color',options:[['auto','Auto'],['black','Black'],['red','Red'],['wine','Wine'],['emerald','Emerald Green'],['ivory','Ivory'],['midnight','Midnight Blue']]},
    {id:'structure',label:'Structure',options:[['auto','Auto'],['two-piece','Two-piece'],['bodysuit','Sheer Bodysuit']]},
    {id:'sheerness',label:'Sheerness',options:[['auto','Auto'],['soft','Soft Sheer'],['semi','Semi-sheer'],['high','Very Sheer']]},
    {id:'extras',label:'Extras',options:[['auto','Auto'],['none','None'],['garter','Garter Belt'],['stockings','Matching Thigh-highs'],['garter-stockings','Garter + Stockings']]}
   ]},
   'silk-robe':{label:'Silk Robe',fields:[
    {id:'color',label:'Color',options:[['auto','Auto'],['black','Black'],['champagne','Champagne'],['crimson','Crimson'],['emerald','Emerald Green'],['lavender','Lavender'],['ivory','Ivory']]},
    {id:'length',label:'Length',options:[['auto','Auto'],['short','Short'],['mid-thigh','Mid-thigh'],['knee','Knee-length']]},
    {id:'closure',label:'Robe State',options:[['auto','Auto'],['wrapped','Fully Wrapped'],['tied','Loosely Tied'],['part-open','Partially Open'],['open','Open-front']]},
    {id:'underlayer',label:'Underlayer',options:[['auto','Auto'],['matching','Matching Lingerie'],['contrast','Contrasting Lingerie'],['none','No Undergarments']]},
    {id:'coverage',label:'Coverage',options:[['auto','Auto'],['full','Full Coverage'],['strategic','Strategic Coverage'],['revealing','Revealing']]}
   ]}
  };
  const OUTFIT_VARIATION_RULES={
   'silk-robe':[
    {id:'color',setSafe:false,values:['champagne silk colorway','deep black silk colorway','crimson silk colorway','emerald silk colorway','soft lavender silk colorway','ivory silk colorway']},
    {id:'length',setSafe:false,values:['short robe silhouette','mid-thigh robe length','knee-length robe silhouette']},
    {id:'finish',setSafe:true,values:['subtle satin sheen','soft matte-silk finish','delicate contrast piping','fine lace edging at the cuffs']}
   ],
   'casual-tank':[
    {id:'color',setSafe:false,values:['black neutral colorway','soft white colorway','sage green colorway','burgundy colorway','dusty blue colorway']},
    {id:'fabric',setSafe:true,values:['fine ribbed cotton texture','soft stretch jersey texture','lightweight premium cotton texture']},
    {id:'cut',setSafe:false,values:['cropped waist-length cut','classic fitted hip-length cut','deep scoop neckline','clean square neckline']},
    {id:'pairing',setSafe:false,values:['paired with high-waisted denim shorts','paired with fitted casual trousers','paired with a simple casual skirt']}
   ],
   'red-dress':[
    {id:'fabric',setSafe:true,values:['rich satin finish','soft velvet finish','fluid crepe fabric','subtle silk sheen']},
    {id:'neckline',setSafe:false,values:['elegant sweetheart neckline','clean asymmetric neckline','refined halter neckline','soft draped neckline']},
    {id:'skirt',setSafe:false,values:['high side slit','clean column skirt','softly draped skirt','fitted midi silhouette']},
    {id:'detail',setSafe:true,values:['minimal gold hardware accents','subtle gathered waist detail','clean tailored seams']}
   ],
   'bikini':[
    {id:'color',setSafe:false,values:['deep red colorway','black colorway','cobalt blue colorway','teal colorway','ivory colorway','coral colorway']},
    {id:'top',setSafe:false,values:['triangle bikini top','balconette bikini top','halter bikini top','simple scoop bikini top']},
    {id:'bottom',setSafe:false,values:['classic matching bikini bottoms','high-waisted bikini bottoms','high-cut bikini bottoms','side-tie bikini bottoms']},
    {id:'detail',setSafe:true,values:['clean contrast trim','small metallic ring accents','minimal seamless finish']}
   ],
   'goddess-gown':[
    {id:'color',setSafe:false,values:['royal violet and gold palette','ivory and antique-gold palette','deep emerald and gold palette','midnight blue and silver palette','crimson and bronze palette']},
    {id:'drape',setSafe:true,values:['layered flowing drapery','asymmetric shoulder drape','long elegant cape panels','soft pleated skirt panels']},
    {id:'detail',setSafe:true,values:['celestial embroidery','fine metallic filigree','gemstone clasp details','ornate embroidered border']}
   ],
   'warrior-armor':[
    {id:'metal',setSafe:false,values:['warm gold and bronze metalwork','darkened steel with gold accents','polished silver with deep blue accents','antique bronze with crimson accents']},
    {id:'structure',setSafe:true,values:['sculpted ceremonial breastplate','layered leather-and-metal skirt panels','refined shoulder guards and bracers','fitted articulated armor panels']},
    {id:'detail',setSafe:true,values:['engraved mythic motifs','small gemstone inlays','weathered ceremonial finish','clean polished tournament finish']}
   ],
   'academic-blazer':[
    {id:'palette',setSafe:false,values:['charcoal and ivory palette','navy and cream palette','deep burgundy and black palette','forest green and ivory palette']},
    {id:'blazer',setSafe:true,values:['single-breasted fitted blazer','double-breasted tailored blazer','softly structured blazer with rolled cuffs']},
    {id:'bottom',setSafe:false,values:['tailored pencil skirt','pleated midi skirt','high-waisted tailored trousers']},
    {id:'detail',setSafe:true,values:['subtle crest-style lapel pin','fine piping along the lapels','minimal gold-button accents']}
   ],
   'leather-look':[
    {id:'color',setSafe:false,values:['classic black leather palette','oxblood leather palette','deep espresso leather palette','dark forest-green leather palette']},
    {id:'structure',setSafe:false,values:['fitted leather jacket with sleek skirt','structured leather top with fitted trousers','sleek leather mini dress silhouette','fitted leather vest with tailored bottoms']},
    {id:'finish',setSafe:true,values:['soft matte leather finish','subtle polished sheen','fine stitched paneling','minimal metal hardware']}
   ],
   'cozy-sweater':[
    {id:'color',setSafe:false,values:['warm cream colorway','soft oatmeal colorway','dusty rose colorway','deep forest-green colorway','charcoal colorway']},
    {id:'neckline',setSafe:false,values:['relaxed off-shoulder neckline','soft cowl neckline','classic crew neckline','gentle v-neckline']},
    {id:'texture',setSafe:true,values:['chunky cable-knit texture','fine cashmere knit','soft brushed knit texture','subtle ribbed knit']},
    {id:'pairing',setSafe:false,values:['paired with fitted leggings','paired with soft lounge shorts','paired with a simple knit skirt']}
   ],
   'business-chic':[
    {id:'palette',setSafe:false,values:['black and ivory palette','charcoal and champagne palette','navy and cream palette','deep burgundy and black palette']},
    {id:'structure',setSafe:true,values:['fitted blazer over a silk blouse','clean double-breasted blazer','softly tailored blazer with open collar']},
    {id:'bottom',setSafe:false,values:['tailored pencil skirt','high-waisted trousers','fitted midi skirt']},
    {id:'detail',setSafe:true,values:['minimal gold jewelry','subtle satin blouse sheen','clean executive tailoring']}
   ],
   'lounge-set':[
    {id:'color',setSafe:false,values:['warm cream palette','soft charcoal palette','dusty lavender palette','sage green palette','muted rose palette']},
    {id:'fabric',setSafe:true,values:['soft ribbed lounge fabric','lightweight knit texture','smooth modal fabric','cozy brushed cotton texture']},
    {id:'layer',setSafe:false,values:['with a loose knit cardigan','with a cropped lounge cardigan','without an outer layer']}
   ],
   'night-out-dress':[
    {id:'color',setSafe:false,values:['classic black colorway','deep red colorway','emerald colorway','midnight blue colorway','metallic charcoal colorway']},
    {id:'fabric',setSafe:true,values:['sleek satin finish','soft velvet finish','subtle metallic shimmer','smooth crepe finish']},
    {id:'cut',setSafe:false,values:['asymmetric neckline','halter neckline','clean square neckline','off-shoulder neckline']},
    {id:'detail',setSafe:true,values:['minimal metallic hardware','subtle side ruching','clean fitted seams']}
   ],
   'mirror-cami':[
    {id:'color',setSafe:false,values:['black colorway','deep wine colorway','soft ivory colorway','dusty rose colorway','navy colorway']},
    {id:'trim',setSafe:true,values:['delicate lace neckline trim','clean satin piping','small bow detail at the neckline','minimal scalloped trim']},
    {id:'bottom',setSafe:false,values:['matching soft lounge shorts','matching fitted sleep shorts','simple coordinating shorts']}
   ],
   'sleep-set':[
    {id:'color',setSafe:false,values:['soft blush palette','midnight blue palette','ivory palette','sage green palette','lavender palette']},
    {id:'fabric',setSafe:true,values:['soft cotton-modal fabric','light satin finish','fine ribbed sleep fabric','smooth jersey texture']},
    {id:'pattern',setSafe:false,values:['tiny floral print','minimal solid color','small star pattern','subtle botanical print']},
    {id:'detail',setSafe:true,values:['delicate piping','small lace-trim accents','minimal scalloped edging']}
   ],
   'summer-dress':[
    {id:'color',setSafe:false,values:['white and blue palette','sunny yellow palette','coral and ivory palette','sage and cream palette','soft lavender palette']},
    {id:'pattern',setSafe:false,values:['small floral print','subtle botanical print','clean solid-color styling','fine striped pattern']},
    {id:'neckline',setSafe:false,values:['square neckline','soft sweetheart neckline','halter neckline','simple scoop neckline']},
    {id:'skirt',setSafe:true,values:['flowing midi skirt','light above-knee skirt','soft wrap-style skirt']}
   ],
   'activewear':[
    {id:'color',setSafe:false,values:['lavender colorway','black and cream colorway','deep teal colorway','burgundy colorway','sage green colorway','cobalt colorway']},
    {id:'top',setSafe:false,values:['supportive scoop-neck sports bra','clean racerback sports top','simple square-neck athletic top']},
    {id:'bottom',setSafe:false,values:['matching fitted yoga shorts','high-waisted bike shorts','matching full-length leggings']},
    {id:'detail',setSafe:true,values:['clean contrast trim','minimal seamless construction','subtle ribbed performance texture']}
   ]
  };
  const OUTFIT_BLOCKED={
   'lace-set':['oversized t-shirt over the lace set','sweater over the lace set','denim covering the lace set','robe replacing the lace set'],
   'sheer-set':['oversized t-shirt over the sheer set','sweater over the sheer set','denim covering the sheer set','robe replacing the sheer set','pronounced nipple outline through fabric','nipple protrusion through fabric','nipple poke-through','fabric clinging tightly around the nipple','exposed nipple through sheer garment','transparent bare nipple'],
   'silk-robe':['pajamas under the robe','jeans under the robe','businesswear under the robe','sweater layered under the robe'],
   'nude':['bra','panties','lingerie','robe','shirt','blouse','dress','skirt','pants','shorts','bikini','bodysuit','stockings']
  };
  function currentVariationLevel(){return $('variationLevel')?.value||'balanced'}
  function variationBudget(level=currentVariationLevel()){if(level==='locked')return 0;if(level==='creative')return 4+Math.floor(Math.random()*3);return 2+Math.floor(Math.random()*2)}
  PF.registerCatalog('outfits',1,{OUTFITS:OUTFITS,ADULT_OUTFIT_RULES:ADULT_OUTFIT_RULES,OUTFIT_VARIATION_RULES:OUTFIT_VARIATION_RULES,OUTFIT_BLOCKED:OUTFIT_BLOCKED});
})(window.PromptForge);
