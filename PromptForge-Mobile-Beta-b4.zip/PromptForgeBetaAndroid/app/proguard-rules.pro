# Prompt Forge Beta currently uses no code shrinking in release builds.
