$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectDir

Write-Host "Prompt Forge Beta Android build" -ForegroundColor Cyan

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    throw "Java was not found. Install Android Studio or JDK 17+ first."
}

$Sdk = $env:ANDROID_SDK_ROOT
if (-not $Sdk) { $Sdk = $env:ANDROID_HOME }
if (-not $Sdk) {
    $candidate = Join-Path $env:LOCALAPPDATA "Android\Sdk"
    if (Test-Path $candidate) { $Sdk = $candidate }
}
if (-not $Sdk -or -not (Test-Path $Sdk)) {
    throw "Android SDK not found. Install Android Studio + Android SDK, or set ANDROID_SDK_ROOT."
}
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk

$Tools = Join-Path $ProjectDir ".tools"
$GradleDir = Join-Path $Tools "gradle-8.13"
$GradleBat = Join-Path $GradleDir "bin\gradle.bat"
if (-not (Test-Path $GradleBat)) {
    New-Item -ItemType Directory -Force -Path $Tools | Out-Null
    $Zip = Join-Path $Tools "gradle-8.13-bin.zip"
    Write-Host "Downloading Gradle 8.13..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-8.13-bin.zip" -OutFile $Zip
    Expand-Archive -Path $Zip -DestinationPath $Tools -Force
}

Write-Host "Building debug APK..." -ForegroundColor Yellow
& $GradleBat --no-daemon assembleDebug
if ($LASTEXITCODE -ne 0) { throw "Gradle build failed." }

$Apk = Join-Path $ProjectDir "app\build\outputs\apk\debug\app-debug.apk"
$Out = Join-Path $ProjectDir "PromptForge-Beta-1.0.0-b1.apk"
Copy-Item $Apk $Out -Force
Write-Host "Built: $Out" -ForegroundColor Green
