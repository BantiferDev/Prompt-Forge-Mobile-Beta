# Mobile source snapshot

This APK project was created from the Prompt Forge Beta 1.0 Mobile/PWA Pass after Migration 1. It includes the current tiered/context-aware Athletic body logic, adults-only safety layer, adult pose framework, Nude outfit, Sheer Set coverage refinement, controlled variation + anti-repeat logic, Prompt Inspector, and mobile responsive UI.

Desktop remains the source of truth. Mobile build number: `1.0.0-beta.1`.
